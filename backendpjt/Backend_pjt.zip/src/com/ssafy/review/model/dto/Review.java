package com.ssafy.review.model.dto;

public class Review {
	private int idx;
	private String title;
	private String content;
	private int boardIdx;
	private int writerIdx;
	private int views;
	private String createTime;
	
	public Review() {
		
	}

	public int getIdx() {
		return idx;
	}

	public void setIdx(int idx) {
		this.idx = idx;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public int getBoardIdx() {
		return boardIdx;
	}

	public void setBoardIdx(int boardIdx) {
		this.boardIdx = boardIdx;
	}

	public int getWriterIdx() {
		return writerIdx;
	}

	public void setWriterIdx(int writerIdx) {
		this.writerIdx = writerIdx;
	}

	public int getViews() {
		return views;
	}

	public void setViews(int views) {
		this.views = views;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	@Override
	public String toString() {
		return "Review [idx=" + idx + ", title=" + title + ", content=" + content + ", boardIdx=" + boardIdx
				+ ", writerIdx=" + writerIdx + ", views=" + views + ", createTime=" + createTime + "]";
	}
	
	
}
